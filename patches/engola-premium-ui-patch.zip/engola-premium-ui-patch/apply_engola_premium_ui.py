from pathlib import Path

root = Path(__file__).resolve().parent
index = root / "static" / "index.html"
css = root / "static" / "engola-premium.css"
js = root / "static" / "engola-premium.js"

if not index.exists():
    raise SystemExit(f"Missing {index}")

s = index.read_text(encoding="utf-8")
if 'href="/static/engola-premium.css"' not in s:
    s = s.replace("</head>", '  <link rel="stylesheet" href="/static/engola-premium.css">\n</head>', 1)
if 'src="/static/engola-premium.js"' not in s:
    s = s.replace("</body>", '  <script src="/static/engola-premium.js"></script>\n</body>', 1)
index.write_text(s, encoding="utf-8")
print("Engola premium UI linked.")
print("Next: run the existing test suite, commit, push, and deploy.")
